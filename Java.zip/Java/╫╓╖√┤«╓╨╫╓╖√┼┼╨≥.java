package model;
import java.util.Scanner;
import java.util.Arrays;
public class Arrly {
	public static void main(String[] args) {
	Scanner c=new Scanner(System.in);
	String s1=c.nextLine();
	char []array=s1.toCharArray();
	Arrays.sort(array);
	int i=0;
	while(i<array.length)
	{
		System.out.print(array[i]);
		for (++i; i < array.length && array[i] == array[i - 1]; ++i);
	}
	//System.out.println(s1);
}
}


