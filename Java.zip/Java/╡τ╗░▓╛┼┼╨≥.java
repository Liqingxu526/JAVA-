package r;
import java.util.Scanner;
public class qiqi {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		String []arr = new String[n];
		double []brr = new double[n];
		for(int i=0;i<n;i++){
			String a = input.next();
			double b = input.nextDouble();
			arr[i] = a;
			brr[i] = b;
		}
		for(int i=0;i<n;i++){
			for(int j=0;j<n-1;j++){
				if(arr[j].compareTo(arr[j+1])>0){
					String temp1;
					double temp2;
					temp1 = arr[j+1];
					arr[j+1] = arr[j];
					arr[j] = temp1;
					temp2 = brr[j+1];
					brr[j+1] = brr[j];
					brr[j] = temp2;
				}
			}
				
		}
		for(int i=0;i<n;i++){
			System.out.format("%12.10s", arr[i]);  
			System.out.format("%12.0f", brr[i]);
		    System.out.println();
		}
	}

}

