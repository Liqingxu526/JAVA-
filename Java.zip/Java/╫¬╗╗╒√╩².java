import java.util.*;
public class ren{
public static void main (String[] args){
Scanner reader=new Scanner(System.in);
double a;
a=reader.nextDouble();
System.out.printf("%.0f",a);
}
}
