import java.util.*; 
public class abc {
	public static void main(String[] args) { 
       int sum=0;
       double aver=0;
       Scanner scanner = new Scanner(System.in);
       for (double i=1;i<4;i++) {
    	   sum += scanner.nextInt();
    	   aver = sum/i;
       }
       System.out.printf("%d\n",sum);  
       System.out.printf("%.2f",aver);
    } 
}
