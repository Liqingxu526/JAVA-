package cnm;
import java.util.*;

import java.util.Scanner;

public class Cnm{	
		
			public static void main(String[] args){
				Scanner scanner = new Scanner(System.in);
				int a[];String b[];
				a= new int[50];b=new String[50];
				int num=scanner.nextInt();
				int i=0,t;String ch; 
				for(i=0;i<num;i++){
					b[i] = scanner.next();
					a[i] = scanner.nextInt();
				}
				for(i=0;i<num;i++){
					for(int j=0;j<num-i-1;j++){
						if(a[j]<a[j+1]){
							t=a[j];
							ch=b[j];
							a[j]=a[j+1];
							a[j+1]=t;
							b[j]=b[j+1];
							b[j+1]=ch;
						}
					}
				}
				for(i=0;i<num;i++){
					System.out.printf("%15s",b[i]);
					System.out.printf("%5d\n",a[i]);
				}
			}
}











