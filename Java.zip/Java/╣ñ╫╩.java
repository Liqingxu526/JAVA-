import java.util.*; 
public class xiaoren {

 
   public static void main(String[] args) { 
    Scanner reader = new Scanner(System.in);
	double a;
	int c=0;
	a=reader.nextDouble();
	double b;
	if(a<1000)
	c=1;
	if(a<2000&&a>=1000)
	c=2;
	if(a<3000&&a>=2000)
	c=3;
	if(a<4000&&a>=3000)
	c=4;
	if(a>4000)
	c=5;
	switch(c){
	case 1:break;
	case 2:a=a*0.9;break;
	case 3:a=a*0.85;break;
	case 4:a=a*0.8;break;
	case 5:a=a*0.75;break;
	}
	System.out.printf("%.2f",a);
	}
	}  

