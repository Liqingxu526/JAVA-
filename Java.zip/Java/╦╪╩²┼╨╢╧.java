import java.util.Scanner;
public class Sushu {
	public static boolean isPrime(long l){
	    if (l<2) return false ;
	    for(long i=2;i*i<=l;i++)
	        if(l%i==0) return false;
	    return true;
	}
	
	public static void main(String[] args) {
	    // TODO Auto-generated method stub
	    Scanner sc = new Scanner(System.in);
	    long number = sc.nextLong();
	    if(isPrime(number))
	        System.out.print("1");
	    else
	        System.out.print("0");

	}

}




