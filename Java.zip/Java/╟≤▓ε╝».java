package model;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
public class A {
	static void print(List<Integer> list) {
		for(Integer i:list) {
        	System.out.print(i+" ");
        }
}
	static void DifferenceSet(List<Integer> list1,List<Integer> list2,List<Integer> list3) {
		 boolean flag=true;
	        int  n=0;
	        while(n<list1.size()) {
	        	flag=true;
	        	Integer j=list1.get(n);
	        	int m=0;
	        	Integer k;
	        	while (m<list2.size()) {
	                k=list2.get(m);
	        		if(j==k) {
	        		   flag=false;
	        		   break;
	        		}
	        		m=m+1;
	        	}
	        	if(flag==true) {
	        		list3.add(list1.get(n));
	        	}
	        	n++;
	        }
	        }
	        public static void main(String[] args) {
	    		// TODO Auto-generated method stub
	    		List<Integer> list1=new ArrayList<Integer>();
	            List<Integer> list2=new ArrayList<Integer>();
	            List<Integer> list3=new ArrayList<Integer>();
	            Scanner scanner1 = new Scanner(System.in);
	    		Integer i;
	            do {
	            	i=scanner1.nextInt();
	            	if(i!=-1) list1.add(i);
	            }while(i!=-1);
	            do {
	            	i=scanner1.nextInt();
	            	if(i!=-1) list2.add(i);
	            }while(i!=-1);
	            DifferenceSet(list1, list2, list3);
	            if(list3.isEmpty()==false) {
	              print(list3);
	            }
}
}


