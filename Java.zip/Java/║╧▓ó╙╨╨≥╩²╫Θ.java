
import java.util.*;

import java.util.Scanner;

public class Cnm{	
		
			public static void main(String[] args){
				Scanner scanner = new Scanner(System.in);
				int a[];int b[];int c[];int t;
				a=new int[50];b=new int[50];c=new int[100];
				int m=scanner.nextInt();
				for(int j=0;j<m;j++)
					a[j]=scanner.nextInt();
				int n=scanner.nextInt();
				for(int i=0;i<n;i++) 
					b[i]=scanner.nextInt();
				for(int i=0;i<m;i++)
					c[i]=a[i];
				for(int i=m,j=0;i<m+n;i++,j++)
					c[i]=b[j];
				 
				for( int i=0;i<m+n;i++){
					for(int j=0;j<m+n-i-1;j++){
						if(c[j]>c[j+1]){
							t=c[j];
							c[j]=c[j+1];
							c[j+1]=t;
		}
		}
		}
				for(int i=0;i<m+n;i++)
					System.out.print(c[i]+" ");
			}
}












