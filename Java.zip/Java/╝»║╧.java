
package ren;
import java.util.*;
public class qq {
	public static void main(String[] args)
	{
		String string="";
		Scanner scan=new Scanner(System.in);
		ArrayList<String>arrayList=new ArrayList<String>();
		while(!string.contentEquals("#"))
		{
			string=scan.nextLine();
			arrayList.add(string);
		}
		arrayList.remove("#");
		Object[] arr=arrayList.toArray();
		for(int i=0;i<arrayList.size()-1;i++)
		{
			for(int j=0;j<arrayList.size()-1;j++)
			{
				if(((String)arr[j]).compareTo((String)arr[j+1])>0)
				{
					String temp;
					temp=(String) arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		for(int i=0;i<arrayList.size();i++)
		{
			System.out.println(arr[i]);
		}
	}
}


