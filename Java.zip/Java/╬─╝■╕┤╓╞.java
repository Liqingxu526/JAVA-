package work;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class FileCopy {
    public static void main(String[] args) {
        File oldFile = new File("filecopy.in");
        File newFile = new File("filecopy.out");

        oldFile.renameTo(newFile);

//        try {
//
//            Files.copy(oldFile.toPath(), newFile.toPath());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

    }
}




