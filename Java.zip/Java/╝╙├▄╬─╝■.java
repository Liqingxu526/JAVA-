package model;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;
import javax.swing.text.AbstractDocument.BranchElement;
public class work {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String key=scanner.nextLine();
		int index = 0;
		try {
			BufferedReader bufferedReader=new BufferedReader(new FileReader("1.txt"));
			BufferedWriter bufferedWriter=new BufferedWriter(new FileWriter("2.txt"));
			String line;
			while ((line=bufferedReader.readLine())!=null) {
				for(int i=0;i<line.length();i++){
					bufferedWriter.write(line.charAt(i)^key.charAt(index));
					index++;
					index=index%key.length();
				}
				bufferedWriter.newLine();				
			}
			bufferedReader.close();
			bufferedWriter.close();
			scanner.close();
			} catch (Exception e) {
			e.printStackTrace();
			}
	}
}




